"""Low-level image / mask processing helpers.

Everything here is pure NumPy / OpenCV and CPU-side; the heavy GPU work lives in
``detector.py`` (text segmentation) and ``inpainter.py`` (LaMa).
"""
from __future__ import annotations

import math
from typing import Tuple

import cv2
import numpy as np


# --------------------------------------------------------------------------- #
# Detector pre/post-processing
# --------------------------------------------------------------------------- #
def letterbox_square(
    img: np.ndarray,
    new_shape: int = 1024,
    color: int = 114,
) -> Tuple[np.ndarray, float, int, int]:
    """Resize ``img`` so its longest side == ``new_shape`` and pad to a square.

    Padding is added to the bottom / right only (no centering) which matches the
    post-processing crop used by comic-text-detector. Working with a fixed square
    canvas also keeps us compatible with ONNX exports that have a static input
    shape of 1024x1024.

    Returns ``(canvas, ratio, pad_w, pad_h)`` where ``ratio`` is the scale that
    was applied to the original image and ``pad_w / pad_h`` are the number of
    padded pixels on the right / bottom.
    """
    h, w = img.shape[:2]
    ratio = new_shape / max(h, w)
    new_w, new_h = round(w * ratio), round(h * ratio)

    resized = cv2.resize(img, (new_w, new_h), interpolation=cv2.INTER_LINEAR)

    pad_w = new_shape - new_w
    pad_h = new_shape - new_h
    canvas = cv2.copyMakeBorder(
        resized, 0, pad_h, 0, pad_w, cv2.BORDER_CONSTANT, value=(color, color, color)
    )
    return canvas, ratio, pad_w, pad_h


def to_input_tensor(canvas_bgr: np.ndarray) -> np.ndarray:
    """BGR HWC uint8 canvas -> float32 NCHW RGB tensor normalised to [0, 1]."""
    rgb = cv2.cvtColor(canvas_bgr, cv2.COLOR_BGR2RGB)
    chw = rgb.transpose(2, 0, 1).astype(np.float32) / 255.0
    return chw[None]  # add batch dim


def restore_mask(
    raw_mask: np.ndarray,
    orig_w: int,
    orig_h: int,
    new_shape: int,
    pad_w: int,
    pad_h: int,
) -> np.ndarray:
    """Map a model mask (any spatial size) back onto the original image.

    ``raw_mask`` may be in [0, 1] (post-sigmoid) or [0, 255]; both are handled.
    Output is a uint8 array of probabilities scaled 0-255 at the original size.
    """
    m = np.squeeze(raw_mask).astype(np.float32)
    if m.max() > 1.5:  # already 0-255
        m /= 255.0

    # Upsample to the full square canvas, then strip the bottom/right padding.
    m = cv2.resize(m, (new_shape, new_shape), interpolation=cv2.INTER_LINEAR)
    valid_h = new_shape - pad_h
    valid_w = new_shape - pad_w
    m = m[:valid_h, :valid_w]

    # Back to the original resolution.
    m = cv2.resize(m, (orig_w, orig_h), interpolation=cv2.INTER_LINEAR)
    return np.clip(m * 255.0, 0, 255).astype(np.uint8)


# --------------------------------------------------------------------------- #
# Mask refinement
# --------------------------------------------------------------------------- #
def refine_mask(
    prob_mask: np.ndarray,
    threshold: int = 30,
    dilation: int = 5,
    closing: int = 7,
) -> np.ndarray:
    """Turn a soft probability mask (0-255) into a clean binary mask (0/255).

    * ``threshold`` - probabilities above this become foreground.
    * ``closing``   - morphological close to fuse nearby strokes into solid blobs.
    * ``dilation``  - grow the mask outward so anti-aliased text edges and the
                      faint halo around glyphs are fully covered before inpainting.
    """
    binary = (prob_mask >= threshold).astype(np.uint8) * 255

    if closing > 0:
        k = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (closing, closing))
        binary = cv2.morphologyEx(binary, cv2.MORPH_CLOSE, k)

    if dilation > 0:
        k = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (dilation, dilation))
        binary = cv2.dilate(binary, k)

    return binary


def union_bbox(mask: np.ndarray, pad: int, max_w: int, max_h: int):
    """Bounding box (x0, y0, x1, y1) of all foreground pixels, expanded by ``pad``.

    Returns ``None`` when the mask is empty.
    """
    ys, xs = np.where(mask > 0)
    if xs.size == 0:
        return None
    x0, x1 = int(xs.min()), int(xs.max())
    y0, y1 = int(ys.min()), int(ys.max())
    x0 = max(0, x0 - pad)
    y0 = max(0, y0 - pad)
    x1 = min(max_w, x1 + pad + 1)
    y1 = min(max_h, y1 + pad + 1)
    return x0, y0, x1, y1


def pad_to_modulo(arr: np.ndarray, mod: int = 8) -> np.ndarray:
    """Pad an HWC (or HW) array on the bottom/right so H and W are multiples of ``mod``.

    LaMa's Fourier convolutions require both spatial dims to be divisible by 8.
    Symmetric padding avoids introducing hard borders that the network would
    otherwise try to reconstruct.
    """
    h, w = arr.shape[:2]
    out_h = math.ceil(h / mod) * mod
    out_w = math.ceil(w / mod) * mod
    if out_h == h and out_w == w:
        return arr
    pad = [(0, out_h - h), (0, out_w - w)]
    if arr.ndim == 3:
        pad.append((0, 0))
    return np.pad(arr, pad, mode="symmetric")
