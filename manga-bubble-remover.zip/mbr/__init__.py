"""manga-bubble-remover: GPU batch removal of manga/comic text and speech bubbles."""

__version__ = "1.0.0"
