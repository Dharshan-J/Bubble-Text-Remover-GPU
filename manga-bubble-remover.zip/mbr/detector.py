"""GPU text/bubble detection using comic-text-detector (ONNX Runtime, CUDA).

comic-text-detector is the segmentation model used by BallonsTranslator and
manga-image-translator. It emits a pixel-level text mask covering glyphs both
*inside* speech bubbles and floating *over* artwork, which is exactly what we
need to drive the inpainter. We run it on the GPU via onnxruntime-gpu.
"""
from __future__ import annotations

from typing import List, Optional

import numpy as np
import onnxruntime as ort

from . import imgproc


class TextDetector:
    INPUT_SIZE = 1024  # comic-text-detector square input

    def __init__(
        self,
        model_path: str,
        device: str = "cuda",
        mask_source: str = "mask",
        verbose: bool = False,
    ):
        self.mask_source = mask_source
        self.verbose = verbose
        self._logged_shapes = False

        providers = self._resolve_providers(device)
        so = ort.SessionOptions()
        so.graph_optimization_level = ort.GraphOptimizationLevel.ORT_ENABLE_ALL
        self.session = ort.InferenceSession(model_path, sess_options=so, providers=providers)

        active = self.session.get_providers()
        self.on_gpu = "CUDAExecutionProvider" in active
        if device == "cuda" and not self.on_gpu:
            # Don't hard-fail: detection still works on CPU and the expensive
            # stage (LaMa) stays on the GPU. Just make the situation obvious.
            print(
                "[detector] WARNING: CUDAExecutionProvider unavailable — running "
                "text detection on CPU (LaMa inpainting still uses the GPU).\n"
                "           For full-GPU detection install a CUDA-matched build:\n"
                "             pip uninstall -y onnxruntime onnxruntime-gpu\n"
                "             pip install \"onnxruntime-gpu>=1.19.2\"   # CUDA 12 / cu121 torch\n"
                f"           Active providers: {active}"
            )
        if verbose:
            print(f"[detector] providers: {active}")

        self.input_name = self.session.get_inputs()[0].name
        self.output_names = [o.name for o in self.session.get_outputs()]

    @staticmethod
    def _resolve_providers(device: str) -> List:
        if device == "cuda":
            # cudnn_conv_algo_search=HEURISTIC avoids slow exhaustive autotuning
            # on the first call without hurting steady-state throughput.
            return [
                ("CUDAExecutionProvider", {"cudnn_conv_algo_search": "HEURISTIC"}),
                "CPUExecutionProvider",
            ]
        return ["CPUExecutionProvider"]

    def _pick_mask_output(self, outputs: List[np.ndarray]) -> np.ndarray:
        """Select the text-region mask from the model's outputs.

        Torch return order is ``(blocks, mask, lines)``; the ONNX export keeps
        that order. We still locate the spatial maps defensively in case an
        export reorders them: the two 4-D (N,C,H,W) outputs are ``mask`` and
        ``lines`` respectively.
        """
        # Segmentation maps are large 2-D grids (>=512 px); the detection tensor
        # (`blks`, e.g. 1x25200x11) has a small trailing dim, so the >=64 gate
        # excludes it regardless of output ordering.
        spatial = [o for o in outputs if o.ndim >= 3 and o.shape[-1] >= 64 and o.shape[-2] >= 64]
        if not self._logged_shapes and self.verbose:
            print("[detector] output shapes:", [o.shape for o in outputs])
            self._logged_shapes = True

        if self.mask_source == "lines" and len(spatial) >= 2:
            return spatial[1]
        if self.mask_source == "both" and len(spatial) >= 2:
            return np.maximum(np.squeeze(spatial[0]), np.squeeze(spatial[1]))
        # default: the text-region mask (first spatial output)
        return spatial[0] if spatial else outputs[1]

    def detect(self, img_bgr: np.ndarray) -> np.ndarray:
        """Return a soft text mask (uint8, 0-255) aligned to ``img_bgr``."""
        h, w = img_bgr.shape[:2]
        canvas, _, pad_w, pad_h = imgproc.letterbox_square(img_bgr, self.INPUT_SIZE)
        tensor = imgproc.to_input_tensor(canvas)

        outputs = self.session.run(self.output_names, {self.input_name: tensor})
        raw_mask = self._pick_mask_output(outputs)

        return imgproc.restore_mask(raw_mask, w, h, self.INPUT_SIZE, pad_w, pad_h)
