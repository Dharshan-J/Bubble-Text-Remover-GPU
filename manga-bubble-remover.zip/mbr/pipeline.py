"""End-to-end batch pipeline: detect text -> refine mask -> inpaint -> save.

Disk decode and encode run on a small thread pool so they overlap with GPU
compute: while the GPU cleans page N, worker threads are already decoding page
N+1 and encoding page N-1. The GPU stages (detector + LaMa) run serially on the
main thread, which keeps VRAM bounded and avoids CUDA contention.
"""
from __future__ import annotations

import time
from collections import deque
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass, field
from pathlib import Path
from queue import Queue
from threading import Thread
from typing import List, Optional

import numpy as np
from tqdm import tqdm

from . import imgproc, io_utils
from .detector import TextDetector
from .inpainter import LamaInpainter


@dataclass
class Config:
    detector_model: str
    lama_model: str
    device: str = "cuda"
    output_dir: Optional[Path] = None
    recursive: bool = True
    overwrite: bool = False
    # detection / mask
    mask_source: str = "mask"
    mask_threshold: int = 30
    dilation: int = 5
    closing: int = 7
    # inpaint
    crop: bool = True
    crop_pad: int = 96
    # io
    io_workers: int = 4
    jpeg_quality: int = 95
    verbose: bool = False


@dataclass
class Stats:
    total: int = 0
    processed: int = 0
    skipped_existing: int = 0
    no_text: int = 0
    errors: int = 0
    failures: List[str] = field(default_factory=list)


def process_one(detector: TextDetector, inpainter: LamaInpainter, img, cfg: "Config"):
    """Detect + refine + inpaint a single BGR image.

    Returns ``(result_bgr, had_text)``. When no text is detected the input is
    returned unchanged with ``had_text=False``. Shared by the CLI pipeline, the
    web UI, and the benchmark so they all behave identically.
    """
    prob = detector.detect(img)
    mask = imgproc.refine_mask(
        prob, threshold=cfg.mask_threshold, dilation=cfg.dilation, closing=cfg.closing
    )
    if mask.max() == 0:
        return img, False
    result = inpainter.inpaint(img, mask, crop=cfg.crop, crop_pad=cfg.crop_pad)
    return result, True


def _loader(paths, out_q: Queue, workers: int):
    """Prefetch-decode images into a bounded queue (preserves submission order).

    At most ``workers * 2`` decodes are kept in flight so a large batch never
    materialises every page in RAM at once.
    """
    inflight = max(2, workers * 2)
    with ThreadPoolExecutor(max_workers=workers) as pool:
        it = iter(paths)
        pending = deque()
        for _ in range(inflight):  # prime
            try:
                p = next(it)
            except StopIteration:
                break
            pending.append((p, pool.submit(io_utils.imread_unicode, p)))

        while pending:
            p, fut = pending.popleft()
            try:
                out_q.put((p, fut.result(), None))
            except Exception as exc:  # noqa: BLE001
                out_q.put((p, None, exc))
            try:  # top up to keep the window full
                nxt = next(it)
                pending.append((nxt, pool.submit(io_utils.imread_unicode, nxt)))
            except StopIteration:
                pass
    out_q.put(None)  # sentinel


def run(inputs: List[str], cfg: Config) -> Stats:
    images = io_utils.collect_images(inputs, recursive=cfg.recursive)
    stats = Stats(total=len(images))
    if not images:
        print("[error] no images found.")
        return stats

    out_dir = cfg.output_dir or io_utils.default_output_dir(inputs)
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    # Root used to mirror sub-folder structure into the output dir.
    first = Path(inputs[0]).expanduser()
    input_root = first if first.is_dir() else first.parent

    print(f"[info] {len(images)} image(s) -> {out_dir}")
    print(f"[info] device={cfg.device}  crop={cfg.crop}  dilation={cfg.dilation}px")

    detector = TextDetector(
        cfg.detector_model, device=cfg.device, mask_source=cfg.mask_source, verbose=cfg.verbose
    )
    inpainter = LamaInpainter(cfg.lama_model, device=cfg.device)

    load_q: Queue = Queue(maxsize=max(2, cfg.io_workers))
    Thread(target=_loader, args=(images, load_q, cfg.io_workers), daemon=True).start()

    save_pool = ThreadPoolExecutor(max_workers=cfg.io_workers)
    save_futures = []

    t0 = time.time()
    pbar = tqdm(total=len(images), unit="img", dynamic_ncols=True)
    while True:
        item = load_q.get()
        if item is None:
            break
        src, img, err = item
        pbar.update(1)

        dst = io_utils.output_path_for(src, input_root, out_dir)
        if err is not None:
            stats.errors += 1
            stats.failures.append(f"{src}: load error: {err}")
            continue
        if dst.exists() and not cfg.overwrite:
            stats.skipped_existing += 1
            continue

        try:
            result, had_text = process_one(detector, inpainter, img, cfg)
            if had_text:
                stats.processed += 1
            else:
                stats.no_text += 1
            save_futures.append(
                save_pool.submit(io_utils.imwrite_unicode, dst, result, cfg.jpeg_quality)
            )
        except Exception as exc:  # noqa: BLE001
            stats.errors += 1
            stats.failures.append(f"{src}: {exc}")
            if cfg.verbose:
                import traceback

                traceback.print_exc()

    pbar.close()
    for fut in save_futures:  # surface any write errors
        try:
            fut.result()
        except Exception as exc:  # noqa: BLE001
            stats.errors += 1
            stats.failures.append(f"save error: {exc}")
    save_pool.shutdown(wait=True)

    elapsed = time.time() - t0
    done = stats.processed + stats.no_text
    rate = done / elapsed if elapsed else 0.0
    print(
        f"\n[done] cleaned={stats.processed} no-text={stats.no_text} "
        f"skipped={stats.skipped_existing} errors={stats.errors} "
        f"in {elapsed:.1f}s ({rate:.2f} img/s)"
    )
    if stats.failures:
        print("[failures]")
        for f in stats.failures[:20]:
            print("  -", f)
        if len(stats.failures) > 20:
            print(f"  ... and {len(stats.failures) - 20} more")
    return stats
