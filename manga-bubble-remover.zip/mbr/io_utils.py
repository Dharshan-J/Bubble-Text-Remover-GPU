"""Filesystem helpers: discovering input images and writing results."""
from __future__ import annotations

import os
from pathlib import Path
from typing import List

import cv2
import numpy as np

IMAGE_EXTS = {".jpg", ".jpeg", ".png", ".webp", ".bmp", ".tif", ".tiff"}


def collect_images(inputs: List[str], recursive: bool = True) -> List[Path]:
    """Expand a mix of files and folders into a sorted list of image paths."""
    found: List[Path] = []
    for raw in inputs:
        p = Path(raw).expanduser()
        if p.is_dir():
            it = p.rglob("*") if recursive else p.glob("*")
            found.extend(f for f in it if f.suffix.lower() in IMAGE_EXTS)
        elif p.is_file() and p.suffix.lower() in IMAGE_EXTS:
            found.append(p)
        else:
            print(f"[warn] skipping (not an image/folder): {raw}")
    # De-dup while keeping deterministic order.
    seen, unique = set(), []
    for f in sorted(found):
        rp = f.resolve()
        if rp not in seen:
            seen.add(rp)
            unique.append(f)
    return unique


def default_output_dir(inputs: List[str]) -> Path:
    """Pick a sensible output folder when the user doesn't pass one."""
    first = Path(inputs[0]).expanduser()
    base = first if first.is_dir() else first.parent
    return base.parent / f"{base.name}_cleaned"


def output_path_for(src: Path, input_root: Path, out_dir: Path) -> Path:
    """Mirror the input folder structure under ``out_dir``."""
    try:
        rel = src.resolve().relative_to(input_root.resolve())
    except ValueError:
        rel = Path(src.name)
    return out_dir / rel


def imread_unicode(path: Path) -> np.ndarray:
    """cv2.imread that tolerates non-ASCII paths (common in manga filenames)."""
    data = np.fromfile(str(path), dtype=np.uint8)
    img = cv2.imdecode(data, cv2.IMREAD_COLOR)
    if img is None:
        raise ValueError(f"failed to decode image: {path}")
    return img


def imwrite_unicode(path: Path, img: np.ndarray, jpeg_quality: int = 95) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    ext = path.suffix.lower()
    if ext in (".jpg", ".jpeg"):
        params = [cv2.IMWRITE_JPEG_QUALITY, jpeg_quality]
    elif ext == ".png":
        params = [cv2.IMWRITE_PNG_COMPRESSION, 3]
    elif ext == ".webp":
        params = [cv2.IMWRITE_WEBP_QUALITY, max(jpeg_quality, 90)]
    else:
        params = []
    ok, buf = cv2.imencode(ext, img, params)
    if not ok:
        raise ValueError(f"failed to encode image: {path}")
    buf.tofile(str(path))
