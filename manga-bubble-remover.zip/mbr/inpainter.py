"""GPU inpainting with big-LaMa (TorchScript).

big-LaMa is resolution-robust and excellent at reconstructing screentone /
gradient backgrounds behind erased manga text. We load the scripted ``.pt``
released by IOPaint and run it on CUDA.

Note on precision: the scripted big-LaMa graph is fragile under fp16 autocast
(its Fourier-convolution blocks can produce NaNs), so we run it in fp32 but lean
on TF32 + cuDNN autotuning, which on an RTX 4090 is effectively as fast while
staying numerically safe.
"""
from __future__ import annotations

import numpy as np
import torch

from . import imgproc


class LamaInpainter:
    def __init__(self, model_path: str, device: str = "cuda"):
        if device == "cuda" and not torch.cuda.is_available():
            raise RuntimeError(
                "CUDA requested but torch.cuda.is_available() is False. Install a "
                "CUDA build of PyTorch (see README) and check your NVIDIA driver."
            )
        self.device = torch.device(device)

        # 4090-friendly fast paths.
        torch.backends.cuda.matmul.allow_tf32 = True
        torch.backends.cudnn.allow_tf32 = True
        torch.backends.cudnn.benchmark = True

        self.model = torch.jit.load(model_path, map_location=self.device)
        self.model.eval()
        if device == "cuda":
            self.model = self.model.to(self.device)

    @torch.inference_mode()
    def _run(self, img_rgb: np.ndarray, mask: np.ndarray) -> np.ndarray:
        """Inpaint a single (already padded) RGB image given a binary mask.

        ``img_rgb`` HWC uint8, ``mask`` HW uint8 (0/255). Returns HWC uint8.
        """
        orig_h, orig_w = img_rgb.shape[:2]
        img_p = imgproc.pad_to_modulo(img_rgb, 8)
        mask_p = imgproc.pad_to_modulo(mask, 8)

        img_t = torch.from_numpy(img_p.transpose(2, 0, 1)).float().div_(255.0)
        mask_t = torch.from_numpy(mask_p).float().div_(255.0)
        mask_t = (mask_t > 0).float()

        img_t = img_t.unsqueeze(0).to(self.device, non_blocking=True)
        mask_t = mask_t.unsqueeze(0).unsqueeze(0).to(self.device, non_blocking=True)

        out = self.model(img_t, mask_t)  # 1x3xHxW in [0, 1]
        out = out[0].permute(1, 2, 0).clamp_(0, 1).mul_(255.0)
        res = out.to(torch.uint8).cpu().numpy()

        return res[:orig_h, :orig_w]

    def inpaint(
        self,
        img_bgr: np.ndarray,
        mask: np.ndarray,
        crop: bool = True,
        crop_pad: int = 96,
        full_image_area_ratio: float = 0.5,
    ) -> np.ndarray:
        """Erase masked regions from ``img_bgr`` and return the cleaned BGR image.

        When ``crop`` is enabled we inpaint only the bounding region around the
        text (plus context padding) instead of the whole page — a large speed and
        VRAM win for typical sparse manga text. If the mask covers a big fraction
        of the page we fall back to whole-image inpainting so LaMa keeps enough
        surrounding context. Only masked pixels are written back, so untouched
        artwork is bit-for-bit preserved.
        """
        if mask.max() == 0:
            return img_bgr.copy()

        h, w = img_bgr.shape[:2]
        img_rgb = img_bgr[:, :, ::-1]  # BGR -> RGB view

        bbox = None
        if crop:
            bbox = imgproc.union_bbox(mask, crop_pad, w, h)
            if bbox is not None:
                x0, y0, x1, y1 = bbox
                if (x1 - x0) * (y1 - y0) > full_image_area_ratio * w * h:
                    bbox = None  # too big -> whole-image inpaint

        if bbox is None:
            filled = self._run(np.ascontiguousarray(img_rgb), mask)
            out = img_rgb.copy()
            sel = mask > 0
            out[sel] = filled[sel]
            return np.ascontiguousarray(out[:, :, ::-1])

        x0, y0, x1, y1 = bbox
        roi_rgb = np.ascontiguousarray(img_rgb[y0:y1, x0:x1])
        roi_mask = mask[y0:y1, x0:x1]
        filled_roi = self._run(roi_rgb, roi_mask)

        out = img_rgb.copy()
        roi_out = out[y0:y1, x0:x1]
        sel = roi_mask > 0
        roi_out[sel] = filled_roi[sel]
        out[y0:y1, x0:x1] = roi_out
        return np.ascontiguousarray(out[:, :, ::-1])
